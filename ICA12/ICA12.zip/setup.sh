#!/usr/bin/env bash

apt-get install -y python3 python3-pip
apt-get install -y mathgl
pip3 install "gradescope-utils>=0.2.7"
