/*
 * DCVoltageSource.h
 */
#ifndef DCVOLTAGESOURCE_H
#define DCVOLTAGESOURCE_H

#include "Component.h"

// Class specification for a DC voltage source
// This is a derived class, with the Component class
// as the base class
class DCVoltageSource : public Component
{
	private:
		double srcVoltage;			// source voltage
		double current;				// current drawn from source
	public:
		DCVoltageSource();			// constructor
		void setVoltage(double);	// sets source voltage
		void setCurrent(double);	// sets current

		double getVoltage() const;	// returns source voltage
		double getCurrent() const;  // returns current
		double getPower() const;	// returns P = VI
		
		// writes info aboud a DC voltage source to output file
		void dcvsReport(ofstream &);
};

#endif

