/*
 * ece0301_inclass12_step09.cpp
 */

#include <iostream>
/*
#include "Node.cpp"
#include "Component.cpp"
#include "DCVoltageSource.cpp"
#include "Resistor.cpp"
#include "Network.cpp"
*/
#include "Node.h"
#include "Component.h"
#include "DCVoltageSource.h"
#include "Resistor.h"
#include "Network.h"
using std::string;

int main()
{
	// Open text file for output
	string outputFileName = "ECE 0301 - Electrical Network Reports.txt";
	ofstream outFile;
	outFile.open(outputFileName);

	// Write introductory message to file
	outFile << "ECE 0301 - Electrical Network Simulation\n";

	Network ntwk0(3);					// define a 3-node network

	DCVoltageSource Vs;					// define a DC voltage source
	Vs.setVoltage(12);					// set Vs = 12 V

	// connect the voltage source Vs between nodes 0 and 1
	ntwk0.setCompNodes( &Vs, 0, 1 );

	Resistor R1;						// define a resistor
	R1.setResistance(200);				// set R1 = 200 Ohms

	// connect the resistor R1 between nodes 1 and 2
	ntwk0.setCompNodes( &R1, 1, 2 );

	Resistor R2;						// define another resistor
	R2.setResistance(100);				// set R2 = 100 Ohms

	// connect the resistor R1 between nodes 1 and 2
	ntwk0.setCompNodes( &R2, 2, 0 );
	
	// set the voltage at node 1 to Vs
	ntwk0.setNodeVoltage(1, Vs.getVoltage() );
	// set the voltage at node 2 to Vs/3
	ntwk0.setNodeVoltage(2, Vs.getVoltage()/3 );
	
	// variable to store the current provided by the voltage source
	double Is = Vs.getVoltage() / ( R1.getResistance() + R2.getResistance() );
	// set the current for the voltage source
	Vs.setCurrent(Is);

	ntwk0.ntwkReport(outFile);			// write network info to file
	Vs.dcvsReport(outFile);				// write Vs info to file
	R1.resistorReport(outFile);			// write R1 info to file
	R2.resistorReport(outFile);			// write R2 info to file
	
	outFile.close();					// close output file
	
	return 0;
}


