/*
 * VoltageDivider.cpp
 */
#include "VoltageDivider.h"

//*********************************************************************
// Default constructor for the VoltageDivider class.  Calls the       *
// constructor for the network class, with 3 nodes, and bilds a       *
// circuit with Vs = 1V and R1 = R2 = 1 kOhm.                         *
//*********************************************************************
VoltageDivider::VoltageDivider() : Network::Network(3)
{
	Vs.setVoltage(1.0);					// set Vs = 1 V
	Vs.setNodeAPtr( getNodePtr(0) );	// connect Vs between node 0
	Vs.setNodeBPtr( getNodePtr(1) );	// and node 1
	
	R1.setResistance(1e3);				// set R1 = 1 kOhm
	R1.setNodeAPtr( getNodePtr(1) );	// connect R1 between node 1
	R1.setNodeBPtr( getNodePtr(2) );	// and node 2

	R2.setResistance(1e3);				// set R2 = 1 kOhm
	R2.setNodeAPtr( getNodePtr(2) );	// connect R2 between node 2
	R2.setNodeBPtr( getNodePtr(0) );	// and node 0
	
	update();							// compute all V & I
}

//*********************************************************************
// Alternate constructor for the VoltageDivider class.  Calls the     *
// constructor for the network class, with 3 nodes, and builds a      *
// circuit with Vs, R1 and R2 set to the values of the parameters.    *
//*********************************************************************
VoltageDivider::VoltageDivider(double vSrc, double Ra, double Rb)
	: Network::Network(3)
{
	Vs.setVoltage(vSrc);				// set Vs to 1st parameter
	Vs.setNodeAPtr( getNodePtr(0) );	// connect Vs between node 0
	Vs.setNodeBPtr( getNodePtr(1) );	// and node 1
	
	R1.setResistance(Ra);				// set R1 to 2nd parameter
	R1.setNodeAPtr( getNodePtr(1) );	// connect R1 between node 1
	R1.setNodeBPtr( getNodePtr(2) );	// and node 2

	R2.setResistance(Rb);				// set R2 to 3rd parameter
	R2.setNodeAPtr( getNodePtr(2) );	// connect R2 between node 2
	R2.setNodeBPtr( getNodePtr(0) );	// and node 0

	update();							// compute all V & I
}

//*********************************************************************
// setSrcVoltage sets the source voltage for the voltage source in    *
// this voltage divider network to the value of the parameter.        *
//*********************************************************************
void VoltageDivider::setSrcVoltage(double vSrc)
{	
	Vs.setVoltage(vSrc);
	update();							// compute all V & I
}

//*********************************************************************
// setR1R2 sets the resistances for both resistors in this voltage    *
// divider network to the values of the parameters.                   *
//*********************************************************************
void VoltageDivider::setR1R2(double Ra, double Rb)
{	
	R1.setResistance(Ra);
	R2.setResistance(Rb);
	update();							// compute all V & I
}

//*********************************************************************
// update computes all of the voltages and currents in this voltage   *
// divider circuit, using present values for the source voltage and   *
// resistances.                                                       *
//*********************************************************************
void VoltageDivider::update()
{
	setNodeVoltage( 0, 0.0 );				// set node 0 to ground
	setNodeVoltage( 1, Vs.getVoltage() );	// set node 1 voltage to Vs

	// compute loop current in voltage divider circuit
	double loopCurrent = Vs.getVoltage() 
		/ (R1.getResistance() + R2.getResistance());
	// set current drawn from Vs to loop current
	Vs.setCurrent(loopCurrent);
	// set voltage at node 2 to loop current times R2
	setNodeVoltage( 2, loopCurrent * R2.getResistance() );
}

//*********************************************************************
// voltDivReport writes info about a voltage divider to the file.     *
//*********************************************************************
void VoltageDivider::voltDivReport(ofstream &outFile)
{
	// Line break between network reports
	outFile << "\n------------------------------------------------\n";
	// Write message to indicate index for this network
	outFile << "\nData for Electric Network # "
			<< getNtwkIndex() << ":\n";
	// report component index and source voltage
	outFile << "Network # "<< getNtwkIndex() << " is a Voltage Divider.\n";

	// report network index, number of networks in existence, number 
	// of nodes in existence, number of nodes in this network, and
	// info about each node to output file
	ntwkReport(outFile);
	
	// report number of components in existence
	outFile << "At present, there are " << Vs.getCompCount()
			<< " components in existence.\n";
	
	// report info about voltage source
	Vs.dcvsReport(outFile);
	// report info about R1 and R2
	R1.resistorReport(outFile);
	R2.resistorReport(outFile);
}


