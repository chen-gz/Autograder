/*
 * Resistor.h
 */
#ifndef RESISTOR_H
#define RESISTOR_H

#include "Component.h"

// Class specification for a resistor
// This is a derived class, with the Component class
// as the base class
class Resistor : public Component
{
	private:
		double resistance;				// resistance in Ohms
	public:
		Resistor();						// constructor, default 1kOhm
		
		void setResistance(double);		// sets resistance

		double getResistance() const;	// returns resistance
		double getCurrent() const;		// returns I = V/R
		double getPower() const;		// returns P = VI
		
		// writes info aboud a resistor to output file		
		void resistorReport(ofstream &);
};


#endif
