/*
 * DCCurrentSource.h
 */
#ifndef DCCURRENTSOURCE_H
#define DCCURRENTSOURCE_H

#include "Component.h"

// Class specification for a DC current source
// This is a derived class, with the Component class
// as the base class
class DCCurrentSource : public Component
{
	private:
		double srcCurrent;			// source current
	public:
		DCCurrentSource();			// constructor
		void setCurrent(double);	// sets current
		
		double getCurrent() const;  // returns source current
		double getPower() const;	// returns P = VI
		
		// writes info about a DC current source to output file
		void dccsReport(ofstream &);
};

#endif

