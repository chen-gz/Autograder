/*
 * Component.cpp
 */

#include "Component.h"

//*********************************************************************
// This static member variable must be initialized outside the class. *
//*********************************************************************
int Component::compCount = 0;

//*********************************************************************
// Constructor for the Component class, ensures that each component   *
// is assigned a unique index, and that the static variable always    *
// stores the total number of components in existence.  Initializes   *
// both nodes pointers to nullptr.                                    *
//*********************************************************************
Component::Component()
{
	// set component index to number of components
	compIndex = compCount;
	// increment number of components
	compCount++;
	// Initialize node pointers
	nodeAPtr = nullptr;
	nodeBPtr = nullptr;
}

//*********************************************************************
// getCompCount returns the number of components in existence.        *
//*********************************************************************
int Component::getCompCount() const
{	return compCount;	}

//*********************************************************************
// getCompIndex returns the unique index of this node.                *
//*********************************************************************
int Component::getCompIndex() const
{	return compIndex;	}
		
//*********************************************************************
// setNodeAPtr sets the node pointer for terminal A to the address    *
// passed in as a parameter.                                          *
//*********************************************************************
void Component::setNodeAPtr(Node *nAPtr)
{	nodeAPtr = nAPtr;	}
//*********************************************************************
// setNodeBPtr sets the node pointer for terminal B to the address    *
// passed in as a parameter.                                          *
//*********************************************************************
void Component::setNodeBPtr(Node *nBPtr)
{	nodeBPtr = nBPtr;	}

//*********************************************************************
// getNodeAIndex returns the unique index of the node connected to    *
// terminal A of this component.                                      *
//*********************************************************************
int Component::getNodeAIndex() const
{	return nodeAPtr -> getNodeIndex();	}
//*********************************************************************
// getNodeBIndex returns the unique index of the node connected to    *
// terminal B of this component.                                      *
//*********************************************************************
int Component::getNodeBIndex() const
{	return nodeBPtr -> getNodeIndex();	}

//*********************************************************************
// getTermVoltage returns voltage at node B minus the voltage at node *
// A for this component.  The node pointers are used to access the    *
// node voltages.                                                     *
//*********************************************************************
double Component::getTermVoltage() const
{
	double VA = (*nodeAPtr).getVoltage();		// node A voltage
	double VB = (*nodeBPtr).getVoltage();		// node B voltage
	return VB - VA;								// return difference
}

//*********************************************************************
// compReportwrites information about a component to the output file, *
// including the component index and the nodes to which it is         *
// connected.                                                         *
//*********************************************************************
void Component::compReport(ofstream &outFile)
{
	// write component index and terminal nodes to file
	outFile << "Component # " << getCompIndex()
			<< " is connected between node " << getNodeAIndex()
			<< " and node " << getNodeBIndex() << ".\n";

	// absolute value of terminal voltage
	double compVoltage = (getTermVoltage() >= 0) ?
		getTermVoltage() : -getTermVoltage();
	// index of terminal where polarity of voltage is negative
	int negTermIndex = (getTermVoltage() >= 0) ?
		getNodeAIndex() : getNodeBIndex();

	// write voltage and terminal with negative polarity to file
	outFile << "The Voltage across Component # " << compIndex 
			<< " = " << compVoltage << " Volts,\n";
	outFile << "with the negative terminal at node "
			<< negTermIndex << ".\n";
}


