/*
 * Node.cpp
 */

#include "Node.h"
//*********************************************************************
// This static member variable must be initialized outside the class. *
//*********************************************************************
int Node::nodeCount = 0;

//*********************************************************************
// Constructor for the Node class, ensures that each node is assigned *
// a unique index, and that the static variable always stores the     *
// total number of nodes in existence.                                *
//*********************************************************************
Node::Node()
{
	nodeIndex = nodeCount;		// set node index to number of nodes
	nodeCount++;				// increment number of nodes
	setVoltage(0.0);			// nodes are created with V = 0
}

//*********************************************************************
// getNodeCount returns the number of nodes in existence.             *
//*********************************************************************
int Node::getNodeCount() const
{	return nodeCount;		}

//*********************************************************************
// getNodeIndex returns the unique index of this node                 *
//*********************************************************************
int Node::getNodeIndex() const
{	return nodeIndex;		}

//*********************************************************************
// getVoltage returns the node voltage.                               *
//*********************************************************************
double Node::getVoltage() const
{	return nodeVoltage;		}

//*********************************************************************
// setVoltage sets the node voltage to the value of the parameter.    *
//*********************************************************************
void Node::setVoltage(double v)
{	nodeVoltage = v;		}

//*********************************************************************
// nodeReport writes the node index and voltage to a text file.       *
//*********************************************************************
void Node::nodeReport(ofstream &outFile) const
{
	outFile << "Voltage at node " << nodeIndex 
			<< " = " << nodeVoltage << ".\n";
}

