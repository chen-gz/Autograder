/*
 * VoltageDivider.h
 */
#ifndef VOLTAGEDIVIDER_H
#define VOLTAGEDIVIDER_H

#include "Network.h"
#include "DCVoltageSource.h"
#include "Resistor.h"
using std::ofstream;

// Class specification for a voltage divider
// This is a derived class, with the Network class
// as the base class
class VoltageDivider : public Network
{
	private:
		DCVoltageSource Vs;				// voltage source object
		Resistor R1, R2;				// 2 resistor objects
	public:
		VoltageDivider();				// default constructor
		// alt. constructor, accepts source voltage and resistances
		VoltageDivider(double, double, double);	

		void setSrcVoltage(double);		// set source voltage
		void setR1R2(double, double);	// set resistances

		void update();					// update all V & I

		// writes info about a voltage divider to output file
		void voltDivReport(ofstream &);
};

#endif

