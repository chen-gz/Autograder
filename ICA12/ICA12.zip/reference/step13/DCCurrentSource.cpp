/*
 * DCCurrentSource.cpp
 */
#include "DCCurrentSource.h"

//*********************************************************************
// Constructor for the DCCurrentSource class.  Calls the constructor  *
// for the component class, and initializes the source to 0.          *
//*********************************************************************
DCCurrentSource::DCCurrentSource() 
	: Component::Component()
{	setCurrent(0.0);			}

//*********************************************************************
// setCurrent sets the source current to the value of the parameter.  *
//*********************************************************************
void DCCurrentSource::setCurrent(double I)
{	srcCurrent = I;				}

//*********************************************************************
// getCurrent returns the source current.                             *
//*********************************************************************
double DCCurrentSource::getCurrent() const
{	return srcCurrent;				}

//*********************************************************************
// getPower returns the power supplied buy the source.                *
//*********************************************************************
double DCCurrentSource::getPower() const
{	return getCurrent()*getTermVoltage();	}

//*********************************************************************
// dccsReport writes info about a DC current source to the file.      *
//*********************************************************************
void DCCurrentSource::dccsReport(ofstream &outFile)
{
	// report component index and source current
	outFile << "\nComponent # " << getCompIndex()
			<< " is a DC Current Source, Is = "
			<< srcCurrent << " Amps.\n";

	// report component index, terminals nodes, terminal
	// voltage and polarity to output file
	compReport(outFile);
	
	// absolute value of the current
	double iSrcCurrent = getCurrent() >= 0 ?
		getCurrent() : -getCurrent();
	// node from which the current flows
	int srcNode = getCurrent() >= 0 ?
		getNodeAIndex() : getNodeBIndex();
	// node into which the current flows
	int sinkNode = getCurrent() >= 0 ?
		getNodeBIndex() : getNodeAIndex();

	// report current and direction
	outFile << "The current in this DC Current Source = "
			<< iSrcCurrent << " Amps,\n";
	outFile << "flowing from Node " << srcNode
			<< " to Node " << sinkNode << ".\n";
	// report power supplied
	outFile << "The power supplied by this DC Current Source = "
			<< getPower() << " Watts.\n";
}

