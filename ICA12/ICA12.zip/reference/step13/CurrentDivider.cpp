/*
 * CurrentDivider.cpp
 */
#include "CurrentDivider.h"

//*********************************************************************
// Default constructor for the CurrentDivider class.  Calls the       *
// constructor for the network class, with 2 nodes, and builds a      *
// circuit with Vs = 1V and R1 = R2 = 1 kOhm.                         *
//*********************************************************************
CurrentDivider::CurrentDivider() : Network::Network(2)
{
	Is.setCurrent(1.0);					// set Is = 1 A
	Is.setNodeAPtr( getNodePtr(0) );	// connect Vs between node 0
	Is.setNodeBPtr( getNodePtr(1) );	// and node 1
	
	R1.setResistance(1e3);				// set R1 = 1 kOhm
	R1.setNodeAPtr( getNodePtr(0) );	// connect R1 between node 0
	R1.setNodeBPtr( getNodePtr(1) );	// and node 1

	R2.setResistance(1e3);				// set R2 = 1 kOhm
	R2.setNodeAPtr( getNodePtr(0) );	// connect R2 between node 0
	R2.setNodeBPtr( getNodePtr(1) );	// and node 1
	
	update();							// compute all V & I
}

//*********************************************************************
// Alternate constructor for the CurrentDivider class.  Calls the     *
// constructor for the network class, with 2 nodes, and builds a      *
// circuit with Is, R1 and R2 set to the values of the parameters.    *
//*********************************************************************
CurrentDivider::CurrentDivider(double iSrc, double Ra, double Rb)
	: Network::Network(2)
{
	Is.setCurrent(iSrc);				// set Is to 1st parameter
	Is.setNodeAPtr( getNodePtr(0) );	// connect Vs between node 0
	Is.setNodeBPtr( getNodePtr(1) );	// and node 1
	
	R1.setResistance(Ra);				// set R1 to 2nd parameter
	R1.setNodeAPtr( getNodePtr(0) );	// connect R1 between node 0
	R1.setNodeBPtr( getNodePtr(1) );	// and node 1

	R2.setResistance(Rb);				// set R2 to 3rd parameter
	R2.setNodeAPtr( getNodePtr(0) );	// connect R2 between node 0
	R2.setNodeBPtr( getNodePtr(1) );	// and node 1
	
	update();							// compute all V & I
}

//*********************************************************************
// setSrcCurrent sets the source current for the current source in    *
// this current divider network to the value of the parameter.        *
//*********************************************************************
void CurrentDivider::setSrcCurrent(double iSrc)
{	
	Is.setCurrent(iSrc);
	update();							// compute all V & I
}

//*********************************************************************
// setR1R2 sets the resistances for both resistors in this current    *
// divider network to the values of the parameters.                   *
//*********************************************************************
void CurrentDivider::setR1R2(double Ra, double Rb)
{	
	R1.setResistance(Ra);
	R2.setResistance(Rb);
	update();							// compute all V & I
}

//*********************************************************************
// update computes all of the voltages and currents in this current   *
// divider circuit, using present values for the source current and   *
// resistances.                                                       *
//*********************************************************************
void CurrentDivider::update()
{
	setNodeVoltage( 0, 0.0 );			// set node 0 to ground

	// compute equivalent resistance of R1 and R2 in parallel
	double Req = 1.0 / ( 1/R1.getResistance() + 1/R2.getResistance() );
	// compute voltage at node 1 as Is times Req
	double V1 = Is.getCurrent() * Req;
	// set voltage at node 1
	setNodeVoltage( 1, V1 );
}

//*********************************************************************
// crntDivReport writes info about a current divider to the file.     *
//*********************************************************************
void CurrentDivider::crntDivReport(ofstream &outFile)
{
	// Line break between network reports
	outFile << "\n------------------------------------------------\n";
	// Write message to indicate index for this network
	outFile << "\nData for Electric Network # "
			<< getNtwkIndex() << ":\n";
	// report component index and source voltage
	outFile << "Network # "<< getNtwkIndex() << " is a Current Divider.\n";

	// report network index, number of networks in existence, number 
	// of nodes in existence, number of nodes in this network, and
	// info about each node to output file
	ntwkReport(outFile);
	
	// report number of components in existence
	outFile << "At present, there are " << Is.getCompCount()
			<< " components in existence.\n";
	
	// report info about current source
	Is.dccsReport(outFile);
	// report info about R1 and R2
	R1.resistorReport(outFile);
	R2.resistorReport(outFile);
}
