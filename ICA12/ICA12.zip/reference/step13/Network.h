/*
 * Network.h
 */
#ifndef NETWORK_H
#define NETWORK_H

#include "Node.h"
#include "Component.h"

// Class specification for a DC electric network
class Network
{
	private:
		static int ntwkCount;		// number of networks in existence
		int ntwkIndex;				// unique index of this network
		int numNodes;				// number of nodes in this network
		Node * nodeList;			// array of nodes for this network
	public:
		Network(int);				// constructor w/ no. of nodes
		~Network();					// destructor
		
		int getNtwkIndex() const;	// returns ntwkIndex
		int getNumNodes() const;	// returns no. nodes in network
		int getNodeCount() const;	// returns no. nodes in existence

		// returns a pointer to one of the nodes in the network
		Node * getNodePtr(int) const;

		// sets the voltage for a node in this network
		void setNodeVoltage(int, double);
		// sets the node pointers for a component in this network
		void setCompNodes(Component *, int, int);

		// writes network info to output file
		void ntwkReport(ofstream &) const;			
};


#endif
