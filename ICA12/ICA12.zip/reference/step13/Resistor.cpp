#include "Resistor.h"

//*********************************************************************
// Constructor for the Resistor class.  Calls the constructor for the *
// component class, and initializes the resistance to 1 kOhm.         *
//*********************************************************************
Resistor::Resistor() : Component::Component()
{	setResistance(1e3);			}

//*********************************************************************
// setResistance sets the resistance to the value of the parameter.   *
//*********************************************************************
void Resistor::setResistance(double R)
{	resistance = R;		}

//*********************************************************************
// getResistance returns the resistance.                              *
//*********************************************************************
double Resistor::getResistance() const
{	return resistance;			}

//*********************************************************************
// getCurrent returns I = V/R, where V is the terminal voltage, and R *
// is the resistance.                                                 *
//*********************************************************************
double Resistor::getCurrent() const
{	return	getTermVoltage()/getResistance();	}

//*********************************************************************
// getCurrent returns P = VI, where V is the terminal voltage, and I  *
// is the current.                                                    *
//*********************************************************************
double Resistor::getPower() const
{	return	getTermVoltage()*getCurrent();	}

//*********************************************************************
// resistorReport writes info about a resistor to the output file.    *
//*********************************************************************
void Resistor::resistorReport(ofstream &outFile)
{
	// report component index and resistance
	outFile << "\nComponent # " << getCompIndex()
			<< " is a Resistor, R = "
			<< getResistance() << " Ohms.\n";

	// report component index, terminals nodes, terminal
	// voltage and polarity to output file
	compReport(outFile);	

	// absolute value of the current
	double resistorCurrent = getTermVoltage() >= 0 ?
		getCurrent() : -getCurrent();
	// node from which the current flows
	int srcNode = getTermVoltage() >= 0 ?
		getNodeBIndex() : getNodeAIndex();
	// node into which the current flows
	int sinkNode = getTermVoltage() >= 0 ?
		getNodeAIndex() : getNodeBIndex();

	// report current and direction
	outFile << "The current in this Resistor = "
			<< resistorCurrent << " Amps,\n";
	outFile << "flowing from Node " << srcNode
			<< " to Node " << sinkNode << ".\n";
	// report power dissipated
	outFile << "The power dissipated in this Resistor = "
			<< getPower() << " Watts.\n";
}

