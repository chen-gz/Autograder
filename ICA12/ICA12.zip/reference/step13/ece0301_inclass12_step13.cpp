/*
 * ece0301_inclass12_step13.cpp
 */

#include <iostream>
#include "Node.h"
#include "Component.h"
#include "DCVoltageSource.h"
#include "DCCurrentSource.h"
#include "Resistor.h"
#include "Network.h"
#include "VoltageDivider.h"
#include "CurrentDivider.h"
/*
#include "Node.cpp"
#include "Component.cpp"
#include "DCVoltageSource.cpp"
#include "DCCurrentSource.cpp"
#include "Resistor.cpp"
#include "Network.cpp"
#include "VoltageDivider.cpp"
#include "CurrentDivider.cpp"
* */
using std::string;
using std::ifstream;
using std::cout;

int main()
{
	// Open text file for input
	string inputFileName = "ECE 0301 - Circuits to Simulate.txt";
	ifstream inFile;
	inFile.open(inputFileName);
	
	// Open text file for output
	string outputFileName = "ECE 0301 - Electrical Network Reports.txt";
	ofstream outFile;
	outFile.open(outputFileName);

	// Write introductory message to file
	outFile << "ECE 0301 - Electrical Network Simulation\n";

	// local variables for source voltage, surce current,
	// and resistors
	double Vs, Is, R1, R2;
	// string to store line read from input file
	string lineFromFile;
	
	// loop over lines in input file until file is empty
	while ( getline(inFile, lineFromFile) )
	{
		// Do not proceed if the line read from the file has length 0.
		// This will occur on the last line, which is blank.
		if ( lineFromFile.length() > 0 )
		{
			// if the line is not "Voltage Divider" or "Current
			// Divider", print error message and exit with fail code
			if ( (lineFromFile != "Voltage Divider") && (lineFromFile != "Current Divider") )
			{
				cout << "ERROR! Invalid network type.\n";
				exit(EXIT_FAILURE);
			}
			
			// If this circuit is to be a voltage Divider, ...
			if ( lineFromFile == "Voltage Divider" )
			{
				inFile >> Vs;		// read Vs from file
				inFile >> R1;		// read R1 from file
				inFile >> R2;		// read R2 from file
			
				// define voltage divider object with
				// specified values for Vs, R1 and R2
				VoltageDivider ckt(Vs, R1, R2);
				
				// report circuit info to file
				ckt.voltDivReport(outFile);
			}
			// Otherwise, this circuit is to be a current Divider, ...
			else
			{
				inFile >> Is;		// read Is from file
				inFile >> R1;		// read R1 from file
				inFile >> R2;		// read R2 from file
			
				// define current divider object with
				// specified values for Is, R1 and R2
				CurrentDivider ckt(Is, R1, R2);

				// report circuit info to file
				ckt.crntDivReport(outFile);
			}
		}
	}

	inFile.close();						// close input file
	outFile.close();					// close output file
	
	return 0;
}


