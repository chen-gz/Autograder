/*
 * Node.h
 */
#ifndef NODE_H
#define NODE_H

#include <fstream>
using std::ofstream;

// Class specification for a node in a DC electric network
class Node
{
	private:
		static int nodeCount;		// number of nodes in existence
		int nodeIndex;				// unique index of this node
		double nodeVoltage;			// Voltage at this node rel. ground
	public:
		Node();						// constructor
		void setVoltage(double);	// sets node voltage
		
		int getNodeCount() const;	// returns nodeCount
		int getNodeIndex() const;	// returns nodeIndex
		double getVoltage() const;	// returns nodeVoltage
		
		void nodeReport(ofstream &) const;
									// writes node info to file
};

#endif
