/*
 * Component.cpp
 */
#ifndef COMPONENT_H
#define COMPONENT_H

#include "Node.h"

// Class specification for a component in a DC electric network
class Component
{
	private:
		static int compCount;		// number of components in existence
		int compIndex;				// unique index of this component
		Node * nodeAPtr;			// pointer to node at terminal A
		Node * nodeBPtr;			// pointer to node at terminal B
	public:
		Component();				// constructor
		
		int getCompCount() const;	// returns compCount
		int getCompIndex() const;	// returns compIndex
				
		void setNodeAPtr(Node *);	// sets pointer for node A
		void setNodeBPtr(Node *);	// sets pointer for node B

		int getNodeAIndex() const;	// returns index of node A
		int getNodeBIndex() const;	// returns index of node B

		// returns voltage at node B minus voltage at node A
		double getTermVoltage() const;

		// writes info about a component to the output file
		void compReport(ofstream &);
};

#endif

