/*
 * DCVoltageSource.cpp
 */

#include "DCVoltageSource.h"

//*********************************************************************
// Constructor for the DCVoltageSource class.  Calls the constructor  *
// for the component class, and initializes the source voltage and    *
// current to 0.                                                      *
//*********************************************************************
DCVoltageSource::DCVoltageSource() 
	: Component::Component()
{
	setVoltage(0.0);
	setCurrent(0.0);
}

//*********************************************************************
// setVoltage sets the source voltage to the value of the parameter.  *
//*********************************************************************
void DCVoltageSource::setVoltage(double V)
{	srcVoltage = V;		}

//*********************************************************************
// setCurrent sets the current to the value of the parameter.         *
//*********************************************************************
void DCVoltageSource::setCurrent(double I)
{	current = I;		}

//*********************************************************************
// getVoltage returns the source voltage.                             *
//*********************************************************************
double DCVoltageSource::getVoltage() const
{	return srcVoltage;	}

//*********************************************************************
// getCurrent returns the current.                                    *
//*********************************************************************
double DCVoltageSource::getCurrent() const
{	return current;		}

//*********************************************************************
// getPower returns the power supplied buy the source.                *
//*********************************************************************
double DCVoltageSource::getPower() const
{	return srcVoltage*current;	}

//*********************************************************************
// dcvsReport writes info about a DC voltage source to the file.      *
//*********************************************************************
void DCVoltageSource::dcvsReport(ofstream &outFile)
{
	// report component index and source voltage
	outFile << "\nComponent # " << getCompIndex()
			<< " is a DC Voltage Source, Vs = "
			<< srcVoltage << " Volts.\n";

	// report component index, terminals nodes, terminal
	// voltage and polarity to output file
	compReport(outFile);

	// absolute value of the current
	double vSrcCurrent = getCurrent() >= 0 ?
		getCurrent() : -getCurrent();
	// node from which the current flows
	int srcNode = getCurrent() >= 0 ?
		getNodeAIndex() : getNodeBIndex();
	// node into which the current flows
	int sinkNode = getCurrent() >= 0 ?
		getNodeBIndex() : getNodeAIndex();

	// report current and direction
	outFile << "The current in this DC Voltage Source = "
			<< vSrcCurrent << " Amps,\n";
	outFile << "flowing from Node " << srcNode
			<< " to Node " << sinkNode << ".\n";
	// report power supplied
	outFile << "The power supplied by this DC Voltage Source = "
			<< getPower() << " Watts.\n";
}
