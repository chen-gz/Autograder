/*
 * CurrentDivider.h
 */
#ifndef CURRENTDIVIDER_H
#define CURRENTDIVIDER_H

#include "Network.h"
#include "DCCurrentSource.h"
#include "Resistor.h"
using std::ofstream;

// Class specification for a current divider
// This is a derived class, with the Network class
// as the base class
class CurrentDivider : public Network
{
	private:
		DCCurrentSource Is;				// current source object
		Resistor R1, R2;				// 2 resistor objects
	public:
		CurrentDivider();				// default constructor
		// alt. constructor, accepts source current and resistances
		CurrentDivider(double, double, double);	

		void setSrcCurrent(double);		// set source current
		void setR1R2(double, double);	// set resistances

		void update();					// update all V & I
			
		// writes info about a current divider to output file
		void crntDivReport(ofstream &);
};

#endif

