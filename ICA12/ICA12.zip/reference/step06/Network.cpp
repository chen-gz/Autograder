/*
 * Network.cpp
 */
#include "Network.h"

//*********************************************************************
// This static member variable must be initialized outside the class. *
//*********************************************************************
int Network::ntwkCount = 0;

//*********************************************************************
// Constructor for the Network class, takes an integer paremeter for  *
// the number of nodes.  Ensures that each network is assigned a      *
// unique index, and that the static variable always stores the total *
// number of networks in existence.  Default is 2 nodes.              *
//*********************************************************************
Network::Network(int n = 2)
{
	// set network index to number of networks
	ntwkIndex = ntwkCount;
	// increment number of networks
	ntwkCount++;
	// set number of nodes in this network to parameter
	numNodes = n;
	// allocate memory for an array of nodes
	nodeList = new Node[numNodes];
}

//*********************************************************************
// Destructor for the Network class, frees memorypreviously allocated *
// for array of nodes                                                 *
//*********************************************************************
Network::~Network()
{	
	delete [] nodeList;		
}

//*********************************************************************
// getNtwkIndex returns the unique index of this network.             *
//*********************************************************************
int Network::getNtwkIndex() const
{	return ntwkIndex;					}

//*********************************************************************
// getNumNodes returns the number of nodes in this network            *
//*********************************************************************
int Network::getNumNodes() const
{	return numNodes;	}

//*********************************************************************
// getNodeCount returns the number of nodes in existence, by calling  *
// the corresponding member function for its ground node              *
//*********************************************************************
int Network::getNodeCount() const
{	return nodeList -> getNodeCount();	}

//*********************************************************************
// setNodeVoltage sets the voltage for a node in this network         *
// n is the index of the desired node in the nodeList, and v is the   *
// voltage to set for that node                                       *
//*********************************************************************
void Network::setNodeVoltage(int n, double v)
{	
	if (n < numNodes)
		(nodeList+n) -> setVoltage(v);
}

//*********************************************************************
// setNodeVoltage sets the node pointers for a component in this      *
// network.  c points to a component, and nA and nB are the indices   *
// of the nodes in the node array for this network to which the       *
// component is to be connected.                                      *
//*********************************************************************
void Network::setCompNodes(Component * c, int nA, int nB)
{
	c -> setNodeAPtr(nodeList+nA);
	c -> setNodeBPtr(nodeList+nB);
}

//*********************************************************************
// ntwkReport writes info about a network to the output file          *
//*********************************************************************
void Network::ntwkReport(ofstream &outFile) const
{
	// Line break between network reports
	outFile << "\n------------------------------------------------\n";
	// Write message to indicate index for this network
	outFile << "\nData for Electric Network # "
			<< ntwkIndex << ":\n";
	// Write message to report number of networks in existence
	outFile << "At present, there are " << ntwkCount
			<< " Networks in existence.\n";
	// Write message to report number of nodes in existence
	outFile << "At present, there are " << getNodeCount()
			<< " nodes in existence.\n";
	// Write message to report number of nodes in this network
	outFile << "Network # " << ntwkIndex << " contains "
			<< numNodes << " nodes.\n";
	// Loop to write infor about each node in this network
	for (int n=0; n<numNodes; n++)
		(nodeList+n) -> nodeReport(outFile);
}

