/*
 * ece0301_inclass12_step06.cpp
 */

#include <iostream>
/*
#include "Node.cpp"
#include "Component.cpp"
#include "Network.cpp"
* */
#include "Node.h"
#include "Component.h"
#include "Network.h"
using std::string;

int main()
{
	// Open text file for output
	string outputFileName = "ECE 0301 - Electrical Network Reports.txt";
	ofstream outFile;
	outFile.open(outputFileName);

	// Write introductory message to file
	outFile << "ECE 0301 - Electrical Network Simulation\n";

	Network ntwk0(3);					// define a 3-node network
	Component c0, c1, c2;				// define 3 components
	
	// connect c0 from node 0 to node 1
	ntwk0.setCompNodes( &c0, 0, 1 );
	// connect c1 from node 1 to node 2
	ntwk0.setCompNodes( &c1, 1, 2 );
	// connect c2 from node 2 to node 0
	ntwk0.setCompNodes( &c2, 2, 0 );
	
	// set the voltage at node 1 to -5 V
	ntwk0.setNodeVoltage( 1, -5.0  );
	// set the voltage at node 2 to +1.25 V
	ntwk0.setNodeVoltage( 2, 1.25 );

	ntwk0.ntwkReport(outFile);			// write network info to file
	c0.compReport(outFile);				// write c0 info to file
	c1.compReport(outFile);				// write c1 info to file
	c2.compReport(outFile);				// write c2 info to file
	
	outFile.close();					// close output file
	
	return 0;
}


